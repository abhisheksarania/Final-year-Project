import os
import logging
import json
from flask import Flask
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__)

# Configuration
app.secret_key = os.environ.get("SESSION_SECRET", "dev_key_replace_in_production")

# Database Configuration with error handling
if not os.environ.get("DATABASE_URL"):
    logger.error("DATABASE_URL environment variable is not set")
    raise RuntimeError(
        "DATABASE_URL environment variable must be set. Please check your environment configuration."
    )

app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16MB max file size

# Improve database connection handling
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_size": 5,
    "max_overflow": 2,
    "pool_timeout": 30,
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Add custom template filters
@app.template_filter('fromjson')
def fromjson_filter(value):
    try:
        return json.loads(value) if value else {}
    except:
        return {}

with app.app_context():
    import models
    import routes

    # Create all tables
    db.create_all()

    # Log created tables
    tables = db.metadata.tables.keys()
    logger.info(f"Created database tables: {', '.join(tables)}")

    # Verify table creation by checking table existence
    inspector = db.inspect(db.engine)
    existing_tables = inspector.get_table_names()
    logger.info(f"Existing tables in database: {', '.join(existing_tables)}")