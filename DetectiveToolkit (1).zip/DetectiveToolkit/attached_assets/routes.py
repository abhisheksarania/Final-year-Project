from flask import render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from datetime import datetime
import logging
import json
from app import app, db, login_manager
from models import User, ScanResult
from ml_detector import RansomwareDetector

detector = RansomwareDetector()

@login_manager.user_loader
def load_user(id):
    return db.session.get(User, int(id))

@app.route('/')
@login_required
def dashboard():
    scans = ScanResult.query.filter_by(user_id=current_user.id).order_by(ScanResult.timestamp.desc()).all()
    return render_template('dashboard.html', scans=scans)

@app.route('/report/<int:scan_id>')
@login_required
def view_report(scan_id):
    scan = ScanResult.query.filter_by(id=scan_id, user_id=current_user.id).first_or_404()
    return render_template('report.html', scan=scan)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and user.check_password(request.form['password']):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid username or password')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        if User.query.filter_by(username=request.form['username']).first():
            flash('Username already exists')
            return redirect(url_for('register'))

        user = User(
            username=request.form['username'],
            email=request.form['email']
        )
        user.set_password(request.form['password'])

        db.session.add(user)
        db.session.commit()

        flash('Registration successful')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/scan', methods=['POST'])
@login_required
def scan():
    if 'file' not in request.files:
        return {'error': 'No file provided'}, 400

    file = request.files['file']
    if file.filename == '':
        return {'error': 'No file selected'}, 400

    try:
        filename = secure_filename(file.filename)
        file_content = file.read()

        # Log file details
        logging.info(f"Processing file: {filename}, size: {len(file_content)} bytes")

        result = detector.predict(file_content)

        try:
            scan_result = ScanResult(
                user_id=current_user.id,
                filename=filename,
                timestamp=datetime.utcnow(),
                is_ransomware=result['is_ransomware'],
                confidence=result['confidence'],
                file_size=result['file_size'],
                file_type=result['file_type'],
                entropy_score=result['entropy_score'],
                contains_executable=result['contains_executable'],
                encryption_detected=result['encryption_detected'],
                analysis_details=result['analysis_details']
            )

            db.session.add(scan_result)
            db.session.commit()

            # Include the scan_id in the response for redirect to detailed report
            return {
                'filename': filename,
                'is_ransomware': result['is_ransomware'],
                'confidence': result['confidence'],
                'scan_id': scan_result.id
            }

        except Exception as db_error:
            logging.error(f"Database error while saving scan result: {str(db_error)}")
            return {
                'filename': filename,
                'is_ransomware': result['is_ransomware'],
                'confidence': result['confidence']
            }

    except Exception as e:
        logging.error(f"Scan failed: {str(e)}")
        return {'error': f'Scan failed: {str(e)}'}, 500