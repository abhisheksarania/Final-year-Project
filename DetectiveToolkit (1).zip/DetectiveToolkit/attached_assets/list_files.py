import os

def list_project_files():
    """List all important project files"""
    essential_files = []
    exclude_dirs = {'.git', '__pycache__', '.upm', '.config', '.pytest_cache'}
    exclude_files = {'.gitignore', '.replit', 'replit.nix', 'list_files.py'}
    
    for root, dirs, files in os.walk('.'):
        # Skip excluded directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if file not in exclude_files and not file.endswith('.pyc'):
                file_path = os.path.join(root, file)
                # Remove the leading './' if present
                file_path = file_path[2:] if file_path.startswith('./') else file_path
                essential_files.append(file_path)
    
    return sorted(essential_files)

if __name__ == '__main__':
    files = list_project_files()
    print("\nEssential project files:")
    print("=" * 50)
    for file in files:
        print(file)
