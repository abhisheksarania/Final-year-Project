#!/bin/bash

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is required but not installed. Please install Python 3 to continue."
    exit 1
fi

# Check for required environment variables
if [ -z "$DATABASE_URL" ]; then
    echo "Warning: DATABASE_URL environment variable is not set"
    echo "Please set DATABASE_URL before running the application"
    echo "Example command:"
    echo "export DATABASE_URL=\"postgresql://postgres:your_password@localhost:5432/ransomware_detection\""
    exit 1
fi

if [ -z "$SESSION_SECRET" ]; then
    echo "Warning: SESSION_SECRET environment variable is not set"
    echo "Please set SESSION_SECRET before running the application"
    echo "Example command:"
    echo "export SESSION_SECRET=\"your_secret_key\""
    exit 1
fi

# Start the Flask application
echo "Starting Ransomware Detection Tool..."
python3 main.py