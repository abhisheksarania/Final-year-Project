# Ransomware Detection Tool

A comprehensive web-based application that uses machine learning to identify and prevent potential security threats across multiple file types, with enhanced multi-file type scanning capabilities and detailed analysis reporting.

## Features

- Multi-file type scanning (.exe, .zip files)
- Machine learning-based threat detection
- Detailed analysis reports
- User authentication system
- Scan history tracking
- Interactive dashboard
- Advanced file type scanning support (including .exe, .zip files)
- Detailed security analysis reporting

## Requirements

- Python 3.11+
- PostgreSQL database
- Required Python packages (installed automatically)

## Installation

1. Install PostgreSQL on your system:
   - Download from: https://www.postgresql.org/download/
   - During installation, note down the password you set for the postgres user

2. Set up environment variables:
   ```
   # Windows (PowerShell)
   $env:DATABASE_URL = "postgresql://postgres:your_password@localhost:5432/ransomware_detection"
   $env:SESSION_SECRET = "your_secret_key"

   # Windows (Command Prompt)
   set DATABASE_URL=postgresql://postgres:your_password@localhost:5432/ransomware_detection
   set SESSION_SECRET=your_secret_key

   # Linux/Mac
   export DATABASE_URL="postgresql://postgres:your_password@localhost:5432/ransomware_detection"
   export SESSION_SECRET="your_secret_key"
   ```

3. Create the database:
   ```sql
   psql -U postgres
   CREATE DATABASE ransomware_detection;
   ```

## Running the Application

1. Windows users:
   ```
   start_app.bat
   ```

2. Linux/Mac users:
   ```
   ./start.sh
   ```

3. Access the application at:
   ```
   http://localhost:5000
   ```

## Troubleshooting

### Database Connection Issues

1. Verify PostgreSQL is running:
   ```
   # Windows
   services.msc (check if PostgreSQL service is running)

   # Linux
   sudo systemctl status postgresql
   ```

2. Check environment variables:
   ```
   # Windows PowerShell
   echo $env:DATABASE_URL

   # Windows Command Prompt
   echo %DATABASE_URL%
   ```

3. Test database connection:
   ```
   psql -U postgres -d ransomware_detection
   ```

### Common Issues

1. "DATABASE_URL not set" error:
   - Make sure to set the environment variable as shown in the installation steps
   - For Windows, try restarting your terminal after setting environment variables

2. Connection refused:
   - Verify PostgreSQL is running
   - Check if the port (default 5432) is correct in your DATABASE_URL
   - Ensure no firewall is blocking the connection

## Security Features

- File entropy analysis
- Executable content detection
- Encryption pattern recognition
- Compression ratio analysis
- Detailed threat reporting